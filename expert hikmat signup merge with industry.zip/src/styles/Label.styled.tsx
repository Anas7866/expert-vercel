 import styled from "styled-components"
 export const Label=styled.div`
  font-size: 14px;
  font-weight:500;
  font-stretch: normal;
  font-style: normal;
  letter-spacing: normal; 
  color: #ccd2d8; 
  padding:8px;
`