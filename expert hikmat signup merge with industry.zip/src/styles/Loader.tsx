import styled from "styled-components"

export const LoaderIcon =styled.img`
    display:  block ;
    margin:  auto ;
    textAlign: center ;

`