import React from 'react'
import styled from 'styled-components'

 
 export const Text=styled.p`
    display: flex;
    align-items: center;
    justify-content: center;
    alignment-baseline: middle;
    height: 100vh;
` 