import React from "react";

export default function index() {
  return (
    <div>
      <div>
        Industries
        <a href="" className="Learn-more mt-5">
          Learn more
        </a>
      </div>
      <div className="col-md-3">jds</div>
    </div>
  );
}
