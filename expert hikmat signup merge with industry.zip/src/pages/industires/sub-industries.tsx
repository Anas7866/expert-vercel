import React from "react";

export default function subIndustries() {
  return (
    <div>
      <div>
        <p> Sub industries</p>
        <a href="" className="Learn-more mt-5">
          Learn more
        </a>
      </div>
      <div className="col-md-3"></div>
    </div>
  );
}
