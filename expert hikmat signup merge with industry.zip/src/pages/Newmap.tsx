import React from 'react'

const Newmap = () => {
  return (
    <>
    
    
    
    </>
  )
}

export default Newmap