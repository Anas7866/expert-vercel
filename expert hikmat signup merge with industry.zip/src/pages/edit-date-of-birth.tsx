function Dateofbirth() {
  return (
    <div className="col-md-12">
      <div className="container total_height_dashboard mt-1 pt-4 pb-5">
        <div className="row">
          {/* Sidenavigation code  */}
          <div className="col-md-3 ">
            <div className="col-md-12 pr-5">
              <div className="col-md-12 background_color_sidebar px-4 py-2">
                <img
                  className="img-fluid image_icon_width"
                  src="../assets/images/userwhite.png"
                />{" "}
                Profile
              </div>
            </div>
          </div>
          <div className="col-md-9">Anas</div>
        </div>
      </div>
    </div>
  );
}

export default Dateofbirth;
