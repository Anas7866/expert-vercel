import Image from "next/image";


function subServices() {
  return (
    <div className="col-md-12 p-4">
        <div className="row">
            <div className="col-md-4 ">
                <div className="col-md-12 border_card_ind">
                <div className="col-md-12 ">
                    <Image height={211.89} width={421.33} className="img-fluid" src="../assets/Images/girlc.png" alt="girl" />
                </div>
                <div className="col-md-12 py-3 text-center ">
                    <h5><b>Facials</b></h5>
                </div>
                </div>
            </div>
           
        </div>
    </div>
  )
}

export default subServices;

// // height={211.89}
// width={421.33}